export const calLastUpdate = (timestamp) => {
    const date = new Date(timestamp)
    if (isNaN(date.getTime())) return 'unknown'
    const day = String(date.getDate()).padStart(2, '0')
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const year = date.getFullYear()
    const formattedDate = `${day}/${month}/${year}`
    return formattedDate
}

export const exportToImage = (cb) => {
    domtoimage
        .toPng(main)
        .then(async (dataUrl) => {
            cb(dataUrl)
        })
        .catch((error) => {
            alert('oops, something went wrong!', error)
        })
}
